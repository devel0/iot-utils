---
title: Files


---

# Files



* **dir [include](https://github.com/devel0/iot-utils/tree/main/data/api/Files/dir_d44c64559bbebec7f509842c48db8b23.md#dir-include)** 
    * **file [include/constant-utils.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/constant-utils_8h.md#file-constant-utils.h)** 
    * **file [include/debounced-button.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/debounced-button_8h.md#file-debounced-button.h)** 
    * **file [include/debounced-rotary.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/debounced-rotary_8h.md#file-debounced-rotary.h)** 
    * **file [include/number-utils.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/number-utils_8h.md#file-number-utils.h)** 
    * **file [include/obj-utils.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/obj-utils_8h.md#file-obj-utils.h)** 
    * **file [include/slist.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/slist_8h.md#file-slist.h)** 
    * **file [include/string-utils.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/string-utils_8h.md#file-string-utils.h)** 
    * **file [include/sys-debug.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/sys-debug_8h.md#file-sys-debug.h)** 
    * **file [include/timer-utils.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/timer-utils_8h.md#file-timer-utils.h)** 
    * **file [include/vector-utils.h](https://github.com/devel0/iot-utils/tree/main/data/api/Files/vector-utils_8h.md#file-vector-utils.h)** 



-------------------------------


