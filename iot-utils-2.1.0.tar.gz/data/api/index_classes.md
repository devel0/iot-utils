---
title: Classes


---

# Classes



* **class [DebouncedButton](https://github.com/devel0/iot-utils/tree/main/data/api/Classes/class_debounced_button.md)** <br>btn pin will be set as INPUT_PULLUP 
* **class [DebouncedRotary](https://github.com/devel0/iot-utils/tree/main/data/api/Classes/class_debounced_rotary.md)** <br>rotA,B will be set as INPUT_PULLUP 
* **class [SList](https://github.com/devel0/iot-utils/tree/main/data/api/Classes/class_s_list.md)** <br>Templated simple linked-list. 
* **class [SListNode](https://github.com/devel0/iot-utils/tree/main/data/api/Classes/class_s_list_node.md)** <br>Templated simple linked-list node element. 
* **class [nullable](https://github.com/devel0/iot-utils/tree/main/data/api/Classes/classnullable.md)** <br>allow to hold an object value or state that isn't set (nullable) 
* **namespace [std](https://github.com/devel0/iot-utils/tree/main/data/api/Namespaces/namespacestd.md)** 



-------------------------------


